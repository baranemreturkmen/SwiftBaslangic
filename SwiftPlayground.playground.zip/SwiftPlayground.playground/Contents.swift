import UIKit

var greeting = "Hello, playground"
greeting = "Hello Youtube!"

let const = greeting
//const = "deneme"

var nextYear: Int
var bodyTemp: Float
var hasPet: Bool

var arrayOfInts: [Int]//Array<Int>
var dictionaryOfCapitalsByCountry: [String:String]//Dictionary<String,String>
var winningLotteryNumbers: Set<Int>

let number = 42
let fmStation = 91.1
var countingUp = ["one","two"]
var nameByParkingSpace = [13:"Ahmet",56:"Fatma"]

countingUp[0]

//Initializer
let emptyString = String()
let emptyArrayoFınts = [Int]()
let emptySetOfFloat = Set<Float>()

let defaultNumber = Int()
let defaultBool = Bool()

let meaningOfLife = String(number)
let avaibletRooms = Set([205,205,211,305,432])
let defaultFloat = Float()
let floatFromLiteral = Float(32.8)
let float2FromLiteral: Float = 32.8

countingUp.count
emptyString.isEmpty

countingUp.append("three")
countingUp.append(String(4))

//Unicode destekli dil
let kütüphane = "Kütüphane"

let 🚀 = "roket"
🚀.count

//nil = null
var anOptionalFloat: Float?
var anOptionalArrayOfOptionalFloats: [Float?]?

var reading1: Float?
var reading2: Float?
var reading3: Float?

reading1 = 9.8
reading2 = 9.4
reading3 = 9.5
//reading3 = 9.5 çalışma zamanı hatası verir.

//! muallak ama ben sana garantisini veriyorum -> unwrapping
//let avgReading = (reading1!+reading2!+reading3!)/3

//! hataya açık bir kullanım onun yerine
if let reading1 = reading1,
    let reading2 = reading2,
    let reading3 = reading3{
    (reading1+reading2+reading3)/3.0
}
else{
    print("a reading is missing")
}

//Dictionary literalları optional döner çünkü o değer olmayabilir.
/*if let space13Assignee = nameByParkingSpace[13]{
 İçerisinde değer varsa çalışacak bir kod öbeğine sahip oldum.
 }*/
/*countingUp[7] Opsiyonel dönme olayı arraylerde yok o yüzden IndexOutOfRange hatası veriyor.
 */
 
for i in 0..<5{
    print(i)
}

for i in 0...5{
    print(i)
}

for i in 0...number{
    print(i)
}

for string in countingUp{
    print(string)
}

//enumerated hem index hemde string'i bize tuple olarak dönüyor.
for (index,string) in countingUp.enumerated(){
    //string interpolation
    print("\(index): \(string)")
}

nameByParkingSpace[15] = "Gizem"

for(key,value) in nameByParkingSpace{
    print("\(key): \(value)")
}

//PieType String gibi Integer gibi yeni bir tip
enum PieType{
    case apple
    case apricot
    case peach
}

let favoritePie = PieType.apple

let name:String
switch favoritePie{
case .apple:
    name = "Apple Pie"
case .apricot:
    name = "Apricot Pie"
case .peach:
    name = "Peach Pie"
}
name

let macOSVersion: Int = 17
switch macOSVersion{
case 0...8:
    print("Big Cat")
case 9:
    print("Maveric")
case 10:
    print("Yosemite")
default:
    print("New mac version")
}

//Enum caseleri içerisine ham değer/raw value alabiliyor.
enum PieType2:String{
    case apple
    //Kendi varsayılan değerimi atadım.
    case apricot = "Default Apricot Pie"
    case peach
}

let favoritePie2 = PieType2.apricot

let name2:String

switch favoritePie2{
case .apple:
    name2 = "Apple Pie"
case .apricot:
    name2 = "Apricot Pie"
case .peach:
    name2 = "Peach Pie"
}

//Default değer vermiş oldum.
favoritePie2.rawValue

enum Barcode{
    case upc(Int,Int,Int,Int), qrCode(String)
}

var productBarcode = Barcode.upc(8, 85909, 51226, 3)
productBarcode = .qrCode("ABCDEFGHIJKLMNOP")

//Reference Type Object
class ClassName:NSObject{
    
}

//Value Type Object -> Üzerlerine sadece protokol alabiliyorlar.
struct StructName{
    
}
